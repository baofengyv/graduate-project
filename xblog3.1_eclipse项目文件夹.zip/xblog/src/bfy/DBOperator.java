package bfy;

import java.sql.*;


public class DBOperator 
{
	private Connection connection;
	private String driver;
	private String url;
	private String username;
	private String password;
	public DBOperator()
	{
	}
	public DBOperator(String driver , String url 
		, String username , String password)
	{
		this.driver = driver;
		this.url = url;
		this.username = username;
		this.password = password; 
	}
	//�����Ǹ�����Ա���Ե�setter��getter����
	public void setDriver(String driver) {
		this.driver = driver; 
	}
	public void setUrl(String url) {
		this.url = url; 
	}
	public void setUsername(String username) {
		this.username = username; 
	}
	public void setPassword(String password) {
		this.password = password; 
	}
	public String getDriver() {
		return (this.driver); 
	}
	public String getUrl() {
		return (this.url); 
	}
	public String getUsername() {
		return (this.username); 
	}
	public String getPassword() {
		return (this.password); 
	}
	//��ȡ���ݿ�����
	public Connection getConnection() throws Exception
	{
		if (connection == null)
		{
			Class.forName(this.driver);
			connection = DriverManager.getConnection(url,username,password);
		}
		return connection;
	}
	//�����¼
	public boolean insert(String sql , Object... args)
		throws Exception
	{
		PreparedStatement pstmt = getConnection().prepareStatement(sql);
		for (int i = 0; i < args.length ; i++ )
		{
			pstmt.setObject( i + 1 , args[i]);
		}
		if (pstmt.executeUpdate() != 1)
		{
			return false;
		}
		pstmt.close();
		return true;
	}
	//ִ�в�ѯ
	public ResultSet query(String sql , Object... args)
		throws Exception
	{
		PreparedStatement pstmt = getConnection().prepareStatement(sql);
		for (int i = 0; i < args.length ; i++ )
		{
			pstmt.setObject( i + 1 , args[i]);
		}
		return pstmt.executeQuery();
	}
	//ִ���޸�
	public void modify(String sql , Object... args)
		throws Exception
	{
		PreparedStatement pstmt = getConnection().prepareStatement(sql);
		for (int i = 0; i < args.length ; i++ )
		{
			pstmt.setObject( i + 1 , args[i]);
		}
		pstmt.executeUpdate();
		pstmt.close();
	}
	//�ر����ݿ����ӵķ���
	public void closeConnecton()
		throws Exception
	{
		if (connection != null && !connection.isClosed())
		{
			connection.close();
		}
	}
	//ɾ����������
	public void delete(String sql , Object... args)
		throws Exception
	{
			PreparedStatement pstmt = getConnection().prepareStatement(sql);
			for (int i = 0; i < args.length ; i++ )
			{
				pstmt.setObject( i + 1 , args[i]);
			}
			pstmt.executeUpdate();
			pstmt.close();
	}
}
