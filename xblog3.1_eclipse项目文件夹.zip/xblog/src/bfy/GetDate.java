package bfy;

public class GetDate {

	public GetDate() {
		// TODO Auto-generated constructor stub
	}
	public static String get(){

		java.util.Date date=new java.util.Date();
		String s=date.toString();

		String year=s.substring(24,28);
		
		String mon="00";
		switch(s.substring(4,7)){
		 //(Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec).
		
		case "Jan":mon="01";break;
		case "Feb":mon="02";break;
		case "Mar":mon="03";break;
		case "Apr":mon="04";break;
		case "May":mon="05";break;
		case "Jun":mon="06";break;
		case "Jul":mon="07";break;
		case "Aug":mon="08";break;
		case "Sep":mon="09";break;
		case "Oct":mon="10";break;
		case "Nov":mon="11";break;
		case "Dec":mon="12";break;
		default:mon="00";break;
		}
		
		String day=s.substring(8,10);
		
		return year+"-"+mon+"-"+day;
	}

}
