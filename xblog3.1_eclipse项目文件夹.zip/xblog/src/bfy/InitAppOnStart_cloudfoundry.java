package bfy;


import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.json.JSONException;
import org.json.JSONObject;

public class InitAppOnStart_cloudfoundry implements ServletContextListener{
	public InitAppOnStart_cloudfoundry() {}
	@Override
	public void contextInitialized(ServletContextEvent e) {
		
		System.out.println("in listner init");

		ServletContext app=e.getServletContext();
		String envName=app.getInitParameter("envNameMySQL");

		try {
			JSONObject json = new JSONObject(System.getenv(envName));
			JSONObject mysqlCfg = json.getJSONArray("mysql-5.1")
					.getJSONObject(0).getJSONObject("credentials");
			String driver="com.mysql.jdbc.Driver";
			String host = mysqlCfg.getString("host");
			String port = mysqlCfg.getString("port");
			String name = mysqlCfg.getString("name");
			
			String username = mysqlCfg.getString("username");
			String password = mysqlCfg.getString("password");
						
			app.setAttribute("driver", driver);	
			app.setAttribute("url", "jdbc:mysql://"+host+":"+port+"/"+name);
			app.setAttribute("username", username);
			app.setAttribute("password", password);

			/*bfy.DBOperator db=new DBOperator(
				(String)app.getAttribute("driver"),
				(String)app.getAttribute("url"),
				(String)app.getAttribute("username"),
				(String)app.getAttribute("password")
			);*/
			
			
			} catch (JSONException ee) {
				System.err.println(ee.getMessage());
			}
		
	}

	@Override
	public void contextDestroyed(ServletContextEvent e) {
		//bfy.DBOperator db=
		System.out.println("in listner destroy");
	}



	

}
