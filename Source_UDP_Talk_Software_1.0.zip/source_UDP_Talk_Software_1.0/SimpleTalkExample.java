package javaapplication;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JTextArea;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author C
 */
public class SimpleTalkExample 
{       private Thread serverPartThread;
        private ShowPart showPart;
        private ServerPart serverPart;
        private JButton sendButton;
        private JTextArea  textForInput;        
        private int countSendPacks;  //
        
        public SimpleTalkExample()
        {
            countSendPacks=0;
            sendButton= new JButton("确认IP");
            textForInput = new JTextArea(null,1,10);
            showPart = new  ShowPart(sendButton,textForInput);            
            serverPart= new ServerPart(showPart);
            serverPartThread = new Thread (serverPart);
           
            ButtonAction buttonAction = new ButtonAction();
            sendButton.addActionListener(buttonAction);  
            TextAction textAction = new TextAction();
            textForInput.addKeyListener(textAction);
        }
        private class ButtonAction implements ActionListener
            {
                public ButtonAction(){};
                    @Override
                public void actionPerformed(ActionEvent e)
                {
                    String s;
                    String s1;
                    
                    
                    if(e.getSource()==sendButton)
                    {
                        if(showPart.get_flag())  
                            { 
                                if(!(s=showPart.get_textForInput()).equals(""))
                                {
                                    s1=countSendPacks+"："+s;
                                            try {
                                    serverPart.send(s1);
                                            } catch (IOException ex) {
                                            Logger.getLogger(SimpleTalkExample.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                    showPart.append_textForShow("发出"+countSendPacks+"："+s+"\n");
                                    countSendPacks++;
                                    countSendPacks=(countSendPacks)%10;
                                    showPart.clear_textForInput();
                                }
                            }
                        else 
                            {
                                showPart.set_flag(true);
                                s = showPart.get_textForInput();
                                    try {
                                serverPart.set_IPAddress(convertStringTo4bytesIPAddress(s));
                                    } catch (UnknownHostException ex) {
                                    Logger.getLogger(SimpleTalkExample.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                showPart.set_button("发送");
                                showPart.clear_textForInput();
                                showPart.append_textForShow("\n"+"IP设为："+serverPart.get_IPAddress().toString()+"\n");
                            }
                      }
                }
            }
        private class TextAction implements KeyListener
        {
            private boolean ctrl=false ;
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) 
            {
                int a= e.getKeyCode();
                String s;
                String s1;
                
                switch (showPart.get_flag_boxs())
                {                    
                    case 0:
                    {
                        if(a==KeyEvent.VK_ENTER)
                        {
                                if(showPart.get_flag())  
                                    { 
                                        if(!(s=showPart.get_textForInput()).equals(""))
                                        {
                                            s1=countSendPacks+"："+s;
                                                    try {
                                            serverPart.send(s1);
                                                    } catch (IOException ex) {
                                                    Logger.getLogger(SimpleTalkExample.class.getName()).log(Level.SEVERE, null, ex);
                                                    }
                                            showPart.append_textForShow("发出"+countSendPacks+"："+s+"\n");
                                            countSendPacks++;
                                            countSendPacks=(countSendPacks)%10;
                                        }
                                    }
                                else 
                                    {
                                        showPart.set_flag(true);
                                        s = showPart.get_textForInput();
                                            try {
                                        serverPart.set_IPAddress(convertStringTo4bytesIPAddress(s));
                                            } catch (UnknownHostException ex) {
                                            Logger.getLogger(SimpleTalkExample.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                        showPart.set_button("发送");
                                        showPart.append_textForShow("IP设为："+serverPart.get_IPAddress().toString()+"\n");
                                    }
                        }
                        break;
                    }
                    case 1:
                    {
                        if(a==KeyEvent.VK_CONTROL)      ctrl=true;
                        if(ctrl&&a==KeyEvent.VK_ENTER)  
                        {
                              if(showPart.get_flag())  
                                    { 
                                        if(!(s=showPart.get_textForInput()).equals(""))
                                        {
                                            s1=countSendPacks+"："+s;
                                                    try {
                                            serverPart.send(s1);
                                                    } catch (IOException ex) {
                                                    Logger.getLogger(SimpleTalkExample.class.getName()).log(Level.SEVERE, null, ex);
                                                    }
                                            showPart.append_textForShow("发出"+countSendPacks+"："+s+"\n");
                                            countSendPacks++;
                                            countSendPacks=(countSendPacks)%10;
                                            showPart.clear_textForInput();
                                        }
                                    }
                                else 
                                    {
                                        showPart.set_flag(true);
                                        s = showPart.get_textForInput();
                                            try {
                                        serverPart.set_IPAddress(convertStringTo4bytesIPAddress(s));
                                            } catch (UnknownHostException ex) {
                                            Logger.getLogger(SimpleTalkExample.class.getName()).log(Level.SEVERE, null, ex);
                                            }
                                        showPart.set_button("发送");
                                        showPart.append_textForShow("IP设为："+serverPart.get_IPAddress().toString()+"\n");
                                        showPart.clear_textForInput(); 
                                    }
                        }          
                        break;
                    }
                }
            }
            @Override
            public void keyReleased(KeyEvent e)
            {
                int a = e.getKeyCode();
                switch (showPart.get_flag_boxs())
                {
                    case 0:
                    {
                        if(a==KeyEvent.VK_ENTER) showPart.clear_textForInput();
                        break;
                    }
                    case 1:
                    {
                        if(a==KeyEvent.VK_CONTROL) ctrl=false;
                        break;                        
                    }
                }
                
                
            }
        }

        public void serverPartThreadstart() { serverPartThread.start();}
        
        private byte[] convertStringTo4bytesIPAddress(String s)
               {
                   s=s.trim();            
                   int sum, n, i;
                   byte[] addr = new byte[4];
                   
                   char[] temp = s.toCharArray();        
                   for(i=0,n=0;i<s.length()&&n<4;i++,n++)
                   {
                       sum=0;
                       while(i<s.length()&&temp[i]>='0'&&temp[i]<='9'&&sum<256)
                        {
                            sum*=10;
                            sum+=temp[i]-'0';
                            i++;
                        }
                       if(sum<256)   addr[n]=(byte) sum;
                       else  addr[n]=0;            
                    }        
                    return addr;
               }
       
}
