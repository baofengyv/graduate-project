package javaapplication;



/**
 *
 * @author C
 */
public class ZhuLei //这是主类
{
    public static void main(String args[])
    {
       SimpleTalkExample mySimpleTalkExample=new SimpleTalkExample();
       mySimpleTalkExample.serverPartThreadstart();
     }
    
    
}
