package javaapplication;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author C
 */


import java.io.IOException;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerPart implements Runnable
{
	DatagramSocket serverSocket;
	byte[] receiveData,sendData;
	String sentence;
        ShowPart show;
        InetAddress IPAddress;

        ServerPart(ShowPart showReference)
	{
                show=showReference;                        
		receiveData = new byte[1024];
                     try {
                serverSocket =new DatagramSocket(13940); //try catch 环绕
                     } catch (SocketException ex) {
                     Logger.getLogger(ServerPart.class.getName()).log(Level.SEVERE, null, ex);
                     }                    
	}

            @Override
	public void run()
	{
		while (true)
		{
			DatagramPacket receivePacket = new DatagramPacket(receiveData,receiveData.length);
                                try {
                        serverSocket.receive(receivePacket);  //try catch 环绕
                                 } catch (IOException ex) {
                                 Logger.getLogger(ServerPart.class.getName()).log(Level.SEVERE, null, ex);
                                 }
                        if(!show.get_flag())
                        {
                            show.set_flag(true);
                            show.set_button("发送");
                            IPAddress = receivePacket.getAddress();
                            show.append_textForShow("\n可以与："+IPAddress.getHostAddress()+"通讯。\n");
                        }
			sentence = (new String (receivePacket.getData())).trim();
                        IPAddress = receivePacket.getAddress();
                        clearReceiveBuffer(receiveData);
			show.append_textForShow("     收到"+sentence+"\n");
		}	
	}

	public void send (String s) throws IOException
	{
		sendData = s.getBytes();
		DatagramPacket sendPacket = new DatagramPacket(sendData,sendData.length,IPAddress,13940); 
		serverSocket.send(sendPacket);	
	}

        public void set_IPAddress(byte[] addr) throws UnknownHostException {
        IPAddress = InetAddress.getByAddress(addr);
    }

        private void clearReceiveBuffer(byte[] b) 
        {
        for(int i=0;i<b.length;i++)  b[i] =0;
    }

        public InetAddress get_IPAddress() {
        return IPAddress;
    }
}