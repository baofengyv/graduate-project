/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication;

/**
 *
 * @author C
 */

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.*;

public class ShowPart extends JFrame {
       
          private boolean flag=false;
          private int flag_boxs=0;
          private JTextArea textForShow;
          private JTextArea textForInput;  
          private JButton button;
          private JRadioButton box1;
          private JRadioButton box2;
	public ShowPart(JButton butt,JTextArea temp)
        {     
             flag =false;
             button=butt;
             button.setText("确认IP");
             
             setTitle("SimpleTalkExample");
             JScrollPane scrollPaneContaintextForShow= new JScrollPane();
             JScrollPane scrollPaneContaintextForInput= new JScrollPane();
       scrollPaneContaintextForShow.setAutoscrolls(true);//
       scrollPaneContaintextForInput.setAutoscrolls(true);//
             
                     
             textForShow = new javax.swing.JTextArea("请在下面输入对方IP\n");
             textForInput = temp;
             textForShow.setLineWrap(true);
             textForShow.setEditable(false);                
             textForInput.setLineWrap(true);
             textForInput.setEditable(true);
             textForShow.setColumns(20);
             textForShow.setRows(5);   
             textForInput.setColumns(20);
             textForInput.setRows(3);
       textForShow.setAutoscrolls(true);//
       textForShow.setAutoscrolls(true);//
             scrollPaneContaintextForShow.setViewportView(textForShow);
             scrollPaneContaintextForInput.setViewportView(textForInput);

             JLabel label = new javax.swing.JLabel("快捷键：");
             label.setText("快捷键：");

             box1 = new javax.swing.JRadioButton("Enter",true);
             box2 = new javax.swing.JRadioButton("Ctrl-Enter",false);
             box1.setText("Enter");
             box2.setText("Ctrl+Enter");

             BoxsListener boxsListener = new BoxsListener();
             ButtonGroup buttonGroup = new ButtonGroup();
             buttonGroup.add(box1);
             buttonGroup.add(box2);       
             box1.addItemListener(boxsListener);
             box2.addItemListener(boxsListener);
                	             
             setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
             //GUI 布局开始     我用NetBeans里的工具设计的   START
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollPaneContaintextForInput)
            .addComponent(scrollPaneContaintextForShow)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(label, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(box1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(box2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(button, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(scrollPaneContaintextForShow, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPaneContaintextForInput, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(box1)
                    .addComponent(box2)
                    .addComponent(button))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        //GUI 布局设计 END
        
        setVisible(true);
        pack();
    }
        public void set_flag(boolean f){ flag = f; }
        public boolean get_flag(){return flag;}
        public int get_flag_boxs(){return flag_boxs;}
        
        public String get_textForInput(){return textForInput.getText();}
        public void append_textForShow(String s){textForShow.append(s);}
        public void clear_textForInput(){  textForInput.setText("");   }  
        public void set_button(String s) {button.setLabel(s);}
                
        private class BoxsListener implements ItemListener
        {
            public BoxsListener()    {  }  @Override
            public void itemStateChanged(ItemEvent e) 
            {
                if(e.getItemSelectable()==box1)         flag_boxs=0;
                else if(e.getItemSelectable()==box2)    flag_boxs=1;
            }
        }
}